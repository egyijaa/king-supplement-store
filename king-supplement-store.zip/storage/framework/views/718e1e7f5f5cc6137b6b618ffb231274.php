<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Detail Pembelian</h4><hr>
          <div class="card-title">
            <div class="justify-content-between d-flex d-inline">
              <a href="<?php echo e(url()->previous()); ?>"><i class="fas fa-arrow-left"> Kembali</i></a>
              <a href="<?php echo e(route('admin.supply.print', $supply->id)); ?>" target="_blank"><i class="fas fa-print"></i></a>
            </div>
            <table>
              <tr>
                <td>Kode Pembelian</td>
                <td>:</td>
                <td> &nbsp; <?php echo e($supply->code); ?></td>
              </tr>
                <tr>
                    <td>Nama Penjual</td>
                    <td>:</td>
                    <td> &nbsp; <?php echo e($supply->supplier_name); ?></td>
                </tr>
                <tr>
                    <td>Total Item</td>
                    <td>:</td>
                    <td> &nbsp; <?php echo e($supply->productSupply()->count()); ?></td>
                </tr>
                <tr>
                    <td>Tanggal Pembelian</td>
                    <td>:</td>
                    <?php
                    $date = \Carbon\Carbon::parse($supply->supply_date)->format('d-m-Y');
                    ?>
                    <td> &nbsp; <?php echo e($date); ?></td>
                </tr>
                </table>
            </div>
        </div>
        <hr>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <th>
                  No
                </th>
                <th>
                  Kode - Nama Produk
                </th>
                <th>
                  Jumlah
                </th>
                <th>
                  Harga Satuan
                </th>
                <th>
                  Total
                </th>
              </thead>
              <tbody>
                <?php
                    $total = [];
                ?>
                  <?php $__currentLoopData = $product_supplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($key+1); ?></th>
                      <td><?php echo e($product->product->product_code); ?> - <?php echo e($product->product->name); ?></td>
                      <td><?php echo e($product->quantity); ?></td>
                      <td>Rp. <?php echo number_format($product->price,0,',','.'); ?></td>
                      <td>Rp. <?php echo number_format($product->quantity * $product->price,0,',','.'); ?></td>
                  </tr>
                  <?php
                      $total[] =  $product->quantity * $product->price;
                  ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <?php
                        $totalFinal = array_sum($total);
                    ?>
                    <td colspan="4" align="right"><b>Total Akhir</b></td>
                    <td>Rp. <?php echo number_format($totalFinal,0,',','.'); ?></td>
                  </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Laragon\laragon\www\king-supplement-store\resources\views\admin\supply\show.blade.php ENDPATH**/ ?>