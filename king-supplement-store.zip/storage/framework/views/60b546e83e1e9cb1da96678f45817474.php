<?php $__env->startSection('content'); ?>
<style>
    td {
        padding-right: 40px;
    }
</style>
<?php if(session()->get('failed')): ?>
<div class="alert alert-danger alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button> 
    <?php echo e(session()->get('failed')); ?>

</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button> 
    Konfirmasi password tidak sesuai
</div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-4 col-md-12">
        <div class="card">
            <div class="card-header">
                <center>
                    <img src="<?php echo e(url('template/image/profile.png')); ?>" class="img-rounded" style="widtd:100%;height:200px;">
                </center>
            </div>
            <div class="card-body justify-content-center">
                <center>
                <h5><?php echo e($user->name); ?></h5>
                <h5><?php echo e($user->email); ?></h5>
                </center>
            </div>
        </div>
    </div>
    <div class="col-lg-8 col-md-12">
        <div class="card">
            <div class="card-header">
                Ubah Password
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('kasir.profile.update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="old_password">Password Lama</label>
                        <input type="password" class="form-control" id="old_password" name="old_password" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">Password Baru</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirmation_password">Konfirmasi Password</label>
                        <input type="password" class="form-control" id="confirmation_password" name="confirmation_password" required>
                    </div>
                    <hr>
                    <div class="form-group">
                        <button class="btn btn-primary" type="submit">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Laragon\laragon\www\king-supplement-store\resources\views\kasir\profile\index.blade.php ENDPATH**/ ?>