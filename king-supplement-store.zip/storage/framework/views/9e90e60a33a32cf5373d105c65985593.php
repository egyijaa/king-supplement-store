<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header ">
                <i class="now-ui-icons loader_refresh spin"></i> &nbsp; Transaksi Penjualan Hari Ini : 
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable">
                    <thead>
                        <tr>
                            <td>No.</td>
                            <th>Kode Transaksi</th>
                            <th>Waktu</th>
                            <th>Total Pembelian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $purchaseOrder = [];
                        ?>
                        <?php $__currentLoopData = $transactionGet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($transaction->transaction_code); ?>  <a href="<?php echo e(route('kasir.report.show', $transaction->id)); ?>"><i class="fas fa-eye"></i></a></td>
                            <td><?php echo e(date('d M Y H:i:s', strtotime($transaction->created_at))); ?></td>
                            <td>Rp. <?php echo number_format($transaction->purchase_order,0,',','.'); ?></td>
                        </tr>
                        <?php
                            $purchaseOrder[] = $transaction->purchase_order;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <?php
                $totalPurchase = array_sum($purchaseOrder);
                 ?>
            <b>Total Penjualan Hari ini: Rp. <?php echo number_format($totalPurchase,0,',','.'); ?></b>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Laragon\laragon\www\king-supplement-store\resources\views\kasir\dashboard\index.blade.php ENDPATH**/ ?>