<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header justify-content-between d-flex d-inline">
          <h4 class="card-title"> Laporan Transaksi</h4>
        </div>
        <div class="ml-3">
            <button onclick="window.location.reload();" class="btn btn-sm btn-primary">
                <i class="now-ui-icons loader_refresh"></i> Refresh
            </button>
            <p><i style="color: grey">Secara Default menampilkan laporan hari ini, silahkan pilih range tanggal untuk custom</i></p>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('kasir.report.index')); ?>">
            
            <div class="row">
                    <div class="col-4">
                        <label for="from_date">Dari Tanggal</label>
                        <input type="date" id="from_date" name="from_date" value="<?php echo e(Request::get('from_date')); ?>" class="form-control">
                    </div>
                    <div class="col-4">
                        <label for="to_date">Hingga Tanggal</label>
                        <input type="date" id="to_date" name="to_date" value="<?php echo e(Request::get('to_date')); ?>" class="form-control">
                    </div>
                    <div class="col-4">
                        <div class="col-4" style="margin-top: 10px;">
                            <input type="submit" value="Cari" class="btn btn-primary text-white">
                        </div>
                    </div>
            </div>
            </form>
            <form action="<?php echo e(route('kasir.report.index')); ?>">
                <input type="submit" value="Lihat Hari Ini" class="btn btn-warning text-white">
            </form>
            <?php if(Request::get('to_date')): ?>
            <p>Total Pendapatan dari Tanggal <br><?php echo e(Request::get('from_date')); ?> sampai <?php echo e(Request::get('to_date')); ?> =<b> Rp. <?php echo number_format($total_earn,0,',','.'); ?></b></p>
            <?php else: ?>
            <p>Total Pendapatan Hari Ini :<b> Rp. <?php echo number_format($total_earn,0,',','.'); ?></b></p>
            <?php endif; ?>

          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable">
            <thead>
                <th>No</th>
                <th>Kode Transaksi</th>
                <th>Online/Offline</th>
                <th>Metode Pembayaran</th>
                <th>Total Penjualan</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </thead>
              <tbody>
                  <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($key+1); ?></td>
                      <td><?php echo e($transaction->transaction_code); ?> <div style="font-size: 75%"><?php echo e($transaction->user->name); ?></div></td>
                      <td><?php echo e($transaction->method); ?></td>
                      <td>
                        <?php if($transaction->customer_name != null or $transaction->account_number != null): ?>
                          <?php echo e($transaction->payment_method); ?> <br>
                          <?php echo e($transaction->customer_name ?? ''); ?> 
                         - <?php echo e($transaction->account_number ?? ''); ?>

                          <?php else: ?>
                          Tunai
                        <?php endif; ?>
                      </td>
                      <td>Rp. <?php echo number_format($transaction->purchase_order,0,',','.'); ?></td>
                      <td><?php echo e(date('d M Y H:i:s', strtotime($transaction->created_at))); ?></td>
                      <td>
                          <a href="<?php echo e(route('kasir.report.show', $transaction->id)); ?>"><i class="fas fa-eye"></i></a>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Laragon\laragon\www\king-supplement-store\resources\views\kasir\report\index.blade.php ENDPATH**/ ?>