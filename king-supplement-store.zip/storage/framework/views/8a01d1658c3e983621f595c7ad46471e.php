<?php $__env->startSection('content'); ?>

<div class="row mb-4">
    <div class="col-lg-3">
        <div class="card card-chart">
            <div class="card-header">
                <h5 class="card-category">Total Kategori Produk</h5>
                <h4 class="card-title"><?php echo e($categories); ?></h4>
                <div class="dropdown">
                    <button type="button" class="btn btn-round btn-outline-default dropdown-toggle btn-simple btn-icon no-caret" data-toggle="dropdown">
                        <i class="now-ui-icons loader_gear"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="<?php echo e(route('admin.category.index')); ?>">Lihat Detail</a>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <a href="<?php echo e(route('admin.category.index')); ?>"><i class="now-ui-icons ui-1_zoom-bold"></i> Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card card-chart">
            <div class="card-header">
                <h5 class="card-category">Total Produk</h5>
                <h4 class="card-title"><?php echo e($products); ?></h4>
                <div class="dropdown">
                    <button type="button" class="btn btn-round btn-outline-default dropdown-toggle btn-simple btn-icon no-caret" data-toggle="dropdown">
                        <i class="now-ui-icons loader_gear"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="<?php echo e(route('admin.product.index')); ?>">Lihat Detail</a>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <a href="<?php echo e(route('admin.product.index')); ?>"><i class="now-ui-icons ui-1_zoom-bold"></i> Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card card-chart">
            <div class="card-header">
                <h5 class="card-category">Total Transaksi</h5>
                <h4 class="card-title"><?php echo e($transactions); ?></h4>
                <div class="dropdown">
                    <button type="button" class="btn btn-round btn-outline-default dropdown-toggle btn-simple btn-icon no-caret" data-toggle="dropdown">
                        <i class="now-ui-icons loader_gear"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="<?php echo e(route('admin.report.index')); ?>">Lihat Detail</a>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <a href="<?php echo e(route('admin.report.index')); ?>"><i class="now-ui-icons ui-1_zoom-bold"></i> Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card card-chart">
            <div class="card-header">
                <h5 class="card-category">Total Pembelian</h5>
                <h4 class="card-title"><?php echo e($supplies); ?></h4>
                <div class="dropdown">
                    <button type="button" class="btn btn-round btn-outline-default dropdown-toggle btn-simple btn-icon no-caret" data-toggle="dropdown">
                        <i class="now-ui-icons loader_gear"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="<?php echo e(route('admin.supply.index')); ?>">Lihat Detail</a>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="stats">
                    <a href="<?php echo e(route('admin.supply.index')); ?>"><i class="now-ui-icons ui-1_zoom-bold"></i> Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header ">
                <i class="now-ui-icons loader_refresh spin"></i> &nbsp; <b>Transaksi Penjualan Hari Ini :</b> 
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered display">
                    <thead>
                        <tr>
                            <td>No.</td>
                            <th>Kode Transaksi</th>
                            <th>Waktu</th>
                            <th>Total Pembelian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $purchaseOrder = [];
                        ?>
                        <?php $__currentLoopData = $transactionGet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($transaction->transaction_code); ?>  <a href="<?php echo e(route('admin.report.show', $transaction->id)); ?>"><i class="fas fa-eye"></i></a>
                            
                                <div style="font-size: 75%"><?php echo e($transaction->user->name); ?></div>
                            </td>
                            <td><?php echo e(date('d M Y H:i:s', strtotime($transaction->created_at))); ?></td>
                            <td>Rp. <?php echo number_format($transaction->purchase_order,0,',','.'); ?> <br>
                                <?php echo e($transaction->method); ?>

                            </td>
                        </tr>
                        <?php
                            $purchaseOrder[] = $transaction->purchase_order;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <?php
                $totalPurchase = array_sum($purchaseOrder);
                 ?>
            <b>Total Penjualan Hari ini: Rp. <?php echo number_format($totalPurchase,0,',','.'); ?></b>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header ">
                <i class="now-ui-icons loader_refresh spin"></i> &nbsp; <b>Transaksi Pembelian Hari Ini :</b> 
            </div>
            <div class="card-body ">
                <div class="table-responsive">
                    <table class="table table-bordered display2" id="">
                    <thead>
                      <th>
                        Nama Penjual
                      </th>
                      <th>
                        Total Item
                      </th>
                      <th>
                        Total Pembelian
                      </th>
                    </thead>
                    <tbody>
                        <?php
                        $totalBuy = [];
                        ?>
                        <?php $__currentLoopData = $supplierToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($supply->supplier_name); ?></td>
                            <td><?php echo e($supply->productSupply()->count()); ?></td>
                            <td>Rp. <?php echo number_format($supply->total,0,',','.'); ?>  <a href="<?php echo e(route('admin.supply.show', $supply->id)); ?>"><i class="fas fa-eye"></i></a></td>
                        </tr>
                        <?php
                        $totalBuy[] = $supply->total;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <?php
                $total = array_sum($totalBuy);
                ?>
                <b>Total Pembelian Hari Ini: Rp. <?php echo number_format($total,0,',','.'); ?></b>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header ">
                <i class="now-ui-icons loader_refresh spin"></i> &nbsp; <b>Barang Yang Terjual Hari ini :</b> 
            </div>
            <div class="card-body ">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable">
                    <thead>
                      <th>
                        Barcode - Nama Barang
                      </th>
                      <th>Kategori</th>
                      <th>
                        Harga
                      </th>
                      <th>
                        Total Terjual
                      </th>
                    </thead>
                    <tbody>
                        <?php if($selling == 0): ?>
                        <tr>
                            <td colspan="4" style="text-align: center">Belum Ada Penjualan Hari ini</td>
                        </tr>
                        <?php else: ?>
                        <?php for($i = 0; $i < $totalData; $i++): ?>
                        <tr>
                            <td><?php echo e($result['code'][$i]); ?> - <?php echo e($result['product'][$i]); ?></td>
                            <td><?php echo e($result['category'][$i]); ?></td>
                            <td>Rp. <?php echo number_format($result['price'][$i],0,',','.'); ?></td>
                            <td><?php echo e($result['total'][$i]); ?></td>
                        </tr>
                        <?php endfor; ?>
                        <?php endif; ?>
                    </tbody>
                  </table>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $('table.display').DataTable();
    });

    $(document).ready(function () {
        $('table.display2').DataTable();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Laragon\laragon\www\king-supplement-store\resources\views\admin\dashboard\index.blade.php ENDPATH**/ ?>